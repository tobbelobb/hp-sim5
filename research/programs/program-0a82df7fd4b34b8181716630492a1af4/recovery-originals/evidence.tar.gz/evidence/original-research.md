# HP3 friction and sensor noise robustness

Started 2026-11-05 09:00 UTC. Deadline 10:40 UTC, final reporting reserve starts 10:30 UTC. Human interview complete. Prioritize fewer failures across setups, then accuracy, runtime, explanation. Any anchor above 20 mm fails; every anchor below 5 mm is good. +20% collection effort allowed for substantially fewer failures.

Scope is native Rust, HP3, no layering, known 30 mm radii, zero buildup. No production physics changes, shared dataset edits, default solver switches, Viewer, hardware claims or truth-dependent fit/force/stopping. Source revision 5bb8eb955fa680ddc631b6fb10f988ec3efb497a.

Preflight and command socket checks passed at 09:01 UTC. Attached initial world was layered; isolated full-auto baseline explicitly sets unlayered physics and firmware. Native artifact 66a8451bc1a42310e4dfae166288737e595f75bc1173c8f88e92163afb94a5d8.

Budget: at most 100 wall minutes, 12 jobs, 80 fit invocations, 4000 physical measurement points, 48M total steps. Each job enforces at most 4M steps = 8000 simulated seconds at dt .002 and 600 s wall. Fit cap is tracked in plan logs, keeping 6 iterations initially. One supervised baseline started 09:02 UTC, 6 iterations x 10 sweep points, default forces, events. Its API has no speedup option and runs at scale 1. All session-wrapper runs use supported speedup 25.

Declared split in design.json before policy testing: dev0 nominal, dev1 asymmetric contact friction plus .02 degree read noise; eval0 and eval1 independent permutations plus .03/.05 degree read noise. Do not inspect held-out accuracy until policy is frozen. Contact mu varies .003-.008 around stock .005. Hypothetical modest ranges, not hardware estimates. Spool mu .2 and motor friction untouched. Noise is seeded independent Gaussian degrees applied to each encoder reply before collector averaging, not offline dataset noise. At radius 30 mm, sigma .02-.05 degree is .0105-.0262 mm. Fitting retains production seed 0.

Current hypotheses: default automatic force/measurement strategy remains below 20 mm on these worlds; a simple bounded encoder-observable force strategy can improve failures within +20% effort. No result yet. Next: finish baseline and verified dev1 perturbation; check nominal wrapper control before attributing changes to noise/friction. Policy remains unselected.

09:10 manager steering: six-iteration exploratory cap can precede patience stopping. Label cap exhaustion separately, never as intrinsic autocal failure. Core paired policy runs will use max 12 iterations within per-job step/time limits.
