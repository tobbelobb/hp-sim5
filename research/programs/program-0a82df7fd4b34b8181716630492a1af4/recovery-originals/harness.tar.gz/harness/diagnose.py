"""Posthoc encoder/model diagnostics; never imported by control or fitting."""
import collections, datetime, json, math, sys
from pathlib import Path

S = Path(__file__).resolve().parents[1]

def diagnose(run_id):
    run = S / 'runs' / run_id
    samples = collections.deque(maxlen=100)
    commands = collections.deque(maxlen=20)
    for line in (run / 'sweeps.headless/events.jsonl').open():
        if '"sensor_noise"' not in line and 'M569.4' not in line:
            continue
        row = json.loads(line)
        if row.get('type') == 'sensor_noise' and len(row.get('clean_angles_deg', [])) == 4:
            samples.append(row)
        elif 'M569.4' in line:
            commands.append(row)
    out = {'run_id': run_id, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'purpose': 'Posthoc only. Clean encoders and physical state never select forces or stopping.',
           'last_force_events': list(commands), 'axes': {}}
    if samples:
        end = samples[-1]['sim_time_s']
        out['last_encoder_sim_time_s'] = end
        for i, axis in enumerate('ABCD'):
            stats = {}
            for field in ['clean_angles_deg', 'noisy_angles_deg']:
                narrow = [r[field][i] for r in samples if r['sim_time_s'] >= end - 1]
                wide = [r[field][i] for r in samples if r['sim_time_s'] >= end - 5]
                early = [r[field][i] for r in samples if end - 5 <= r['sim_time_s'] <= end - 2.5]
                late = [r[field][i] for r in samples if r['sim_time_s'] > end - 2.5]
                stats[field] = {'last_1s_range_deg': max(narrow)-min(narrow),
                    'last_5s_range_deg': max(wide)-min(wide),
                    'early_late_mean_difference_deg': abs(sum(early)/len(early)-sum(late)/len(late)) if early and late else None}
            out['axes'][axis] = stats
    terminal = run / 'sweeps.headless/terminal-native.json'
    if terminal.exists():
        state = json.loads(terminal.read_text())
        entities = state['entities']
        out['terminal'] = {'snapshot_stage': state['stage'], 'units': state['units'],
            'selected_entities': [e for e in entities if e['name'] == 'Effector' or e['name'].startswith('Spool')],
            'joints': [{'path': p['id'], 'joint': j['id'], 'entity_a': j['entity_a'], 'entity_b': j['entity_b'],
                       'length_minus_rest_m': j['length_m']-j['rest_length_m'],
                       'constraint_force_n': j['constraint_force_n']} for p in state['paths'] for j in p['joints']]}
        effector = next(e for e in entities if e['name'] == 'Effector')
        out['terminal']['effector_speed_m_s'] = math.sqrt(sum(v*v for v in effector['velocity_m_s']))
        out['interpretation_limit'] = 'Motor/encoder drift need not mean effector motion. Slack spool-side segments with loaded distal segments may reflect model behavior; this is not hardware evidence.'
    (S / 'evidence' / (run_id+'-diagnostic.json')).write_text(json.dumps(out, indent=2)+'\n')
    return {'run': run_id, 'axes': out['axes'], 'terminal_effector_speed_m_s': out.get('terminal', {}).get('effector_speed_m_s')}

if __name__ == '__main__':
    print(json.dumps([diagnose(r) for r in sys.argv[1:]], indent=2))
