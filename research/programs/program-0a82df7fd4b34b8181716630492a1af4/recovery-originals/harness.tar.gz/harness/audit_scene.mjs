import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createHeadlessWorld} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-8b39a80b/hp-sim-3d/app/headlessWorld.js';
import {SceneEntityInfoComponent,CoefficientOfFrictionComponent} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-8b39a80b/src/js/cable_joints_3d/ecs.js';
import {CablePathComponent,CableJointComponent} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-8b39a80b/src/js/cable_joints_3d/cable_joints_core.js';
const S='/workspace/hp-sim5/output/research/sessions/attempt-939c073f49004eb6949910600200be51',id=process.argv[2]||'dev1';
const spec=JSON.parse(fs.readFileSync(`${S}/harness/${id}.json`));
const {world,dt}=createHeadlessWorld(fs.readFileSync(spec.scene,'utf8'),{lineLayeringEnabled:false});
// Session-only plant intervention: stock applyAnchor ignores material mu.
const plantSpec = spec;
for (const entity of (process.argv.includes('--no-injection') ? [] : world.query([SceneEntityInfoComponent]))) {
const info = world.getComponent(entity, SceneEntityInfoComponent);
const route = /^Anchor([ABCD])/.exec(info.name)?.[1];
if (route) world.addComponent(entity, new CoefficientOfFrictionComponent(plantSpec.mu['ABCD'.indexOf(route)]));
}

world.update(dt);
const engine=world.getResource('cableSolverBackend'), name=e=>world.getComponent(e,SceneEntityInfoComponent)?.name;
const contacts=world.query([CablePathComponent]).flatMap(p=>{const path=world.getComponent(p,CablePathComponent);return path.jointEntities.slice(0,-1).map((j,i)=>{const j0=world.getComponent(j,CableJointComponent),j1=world.getComponent(path.jointEntities[i+1],CableJointComponent),entity=j0.entityB,idx=engine.index.get(entity),mu=engine.entityRegion.data[idx*160+105];const v0=j0.attachmentPointA_world.clone().subtract(j0.attachmentPointB_world).normalize(),v1=j1.attachmentPointB_world.clone().subtract(j1.attachmentPointA_world).normalize(),angle=Math.acos(Math.max(-1,Math.min(1,v0.dot(v1))));return {path:name(p),link_type:path.linkTypes[i+1],entity:name(entity),mu_ecs:world.getComponent(entity,CoefficientOfFrictionComponent)?.mu??0,mu_native:mu,angle_rad:angle,capstan_bound:Math.exp(mu*angle),active_branch:mu>1e-9&&angle>1e-9};});});
const state_hash=createHash('sha256').update(JSON.stringify({entities:Array.from(engine.entityRegion.data),paths:engine.pathIds.map((p,i)=>Array.from(engine.transport.path(i)))})).digest('hex');
const suffix=process.argv.includes('--no-injection')?'-no-injection':'-injected';
const out={id,injection:!process.argv.includes('--no-injection'),state_sha256:state_hash,node_version:process.version,utc:new Date().toISOString(),scene:spec.scene,physics_engine:engine.physicsEngine,artifact:engine.artifactInfo.sha256,steps:1,simulated_s:dt,contacts};
fs.writeFileSync(`${S}/evidence/active-friction-audit-${id}${suffix}.json`,JSON.stringify(out,null,2));console.log(JSON.stringify(out));
