"""Count saved workload, including failed/partial collections."""
from pathlib import Path
import datetime,json
S=Path(__file__).resolve().parents[1]
def read(p,default=None):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return default
old=read(S/'budget-ledger.json',{})
rows=[]
for run in [S/'native/friction-baseline',*sorted((S/'runs').iterdir())]:
 if not run.is_dir():continue
 m=read(run/'sweeps.headless/manifest.json',{});clock=read(run/'sweeps.headless/clock.json',{})
 steps=m.get('total_steps',clock.get('total_steps',0)) or 0
 points=sum(sum(1 for _ in p.open()) for p in run.glob('*.partial-points.jsonl'))
 rows.append({'id':run.name,'path':str(run.relative_to(S)),'status':m.get('status','startup/cancelled'),'steps':steps,'simulated_s':m.get('simulated_s',clock.get('simulated_s',0)) or 0,'physical_points':points,'counts_as_collection':steps>0,'wall_s':m.get('wall_s'),'fit_artifacts':len(list((run/'stages').glob('fit-*.json')))})
fits=read(S/'fit-ledger.json',{'reserved_uninstrumented_fits':0,'calls':[]})
probe_steps=sum(read(S/('evidence/torque-slack-'+arm+'.json'),{}).get('steps',0) for arm in ['active','zero'])+4
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadline_utc':'2026-11-05T10:39:32Z','reporting_reserve_utc':'2026-11-05T10:29:00Z','worker_wall_budget_minutes':100,'jobs_counted':sum(r['counts_as_collection'] for r in rows),'job_cap':12,'rows':rows,'collection_steps':sum(r['steps'] for r in rows),'collection_simulated_s':sum(r['simulated_s'] for r in rows),'physical_measurement_points':sum(r['physical_points'] for r in rows),'point_cap':4000,'completed_physical_probe_steps':probe_steps,'failed_unpinned_probe_step_conservative_upper_bound':40000,'conservative_total_steps':sum(r['steps'] for r in rows)+probe_steps+40000,'total_step_cap':48000000,'fits_reserved_or_called':fits['reserved_uninstrumented_fits']+len(fits['calls']),'fit_artifact_count':sum(r['fit_artifacts'] for r in rows),'fit_cap':80,'per_collection_step_cap':4000000,'per_collection_simulated_s_cap':8000,'manager_decision':old.get('manager_decision'),'infrastructure_attempts_excluded_from_collection_counter':['runs/dev1-friction-default','runs/nominal-wrapper'],'counting_rule':'All attempts advancing physics count, even zero-point failures. Two proved zero-physics/collection startup attempts excluded by explicit manager decision. Their wall costs/failures remain. Completed short probes are counted separately;40k allowance conservatively covers unpinned failed attempts.'}
assert out['jobs_counted']<=12 and out['conservative_total_steps']<=48000000 and out['physical_measurement_points']<=4000 and out['fits_reserved_or_called']<=80
(S/'budget-ledger.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['jobs_counted','conservative_total_steps','physical_measurement_points','fits_reserved_or_called','fit_artifact_count']}))
