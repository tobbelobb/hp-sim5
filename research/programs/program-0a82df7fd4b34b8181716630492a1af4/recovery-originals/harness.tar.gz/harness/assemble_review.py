"""Assemble small fixed-evidence extracts; never run physics or fits."""
from pathlib import Path
import collections, datetime, difflib, hashlib, json
S=Path(__file__).resolve().parents[1];ROOT=Path.cwd()
def read(p, default=None):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return default
def save(name,data):
 (S/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
measurements=read(S/'evidence/measurements.json',{})
inputs={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkout':str(ROOT),'source_revision':'5bb8eb955fa680ddc631b6fb10f988ec3efb497a','declared_design':read(S/'design.json'),'chronology_correction':read(S/'evidence/chronology-correction.json'),'invocations':{},'manifests':{},'raw_references':[]}
audits={};snapshots={};windows={};calibration={}
for run in sorted((S/'runs').iterdir()):
 if not run.is_dir():continue
 rid=run.name
 if (run/'invocation.json').exists():inputs['invocations'][rid]=read(run/'invocation.json')
 manifest=read(run/'sweeps.headless/manifest.json')
 if manifest:inputs['manifests'][rid]=manifest
 p=run/'sweeps.headless/intervention-native.json'
 if p.exists():audits[rid]=read(p)
 p=run/'sweeps.headless/terminal-native.json'
 if p.exists() and rid in ['dev1-consistent-preload','eval0-default','eval0-noise-only-default']:snapshots[rid]=read(p)
 if rid in ['dev1-active-default','dev1-consistent-preload','eval0-default']:
  p=run/'sweeps.headless/events.jsonl';last=collections.deque(maxlen=100)
  if p.exists():
   for line in p.open():
    if '"sensor_noise"' not in line:continue
    row=json.loads(line)
    if len(row.get('clean_angles_deg',[]))==4:last.append(row)
   end=last[-1]['sim_time_s'] if last else 0
   windows[rid]={'raw_last_6_sim_s':[row for row in last if row['sim_time_s']>=end-6],'diagnostic':read(S/('evidence/'+rid+'-diagnostic.json')) or read(S/'evidence/dev1-failure-diagnostic.json')}
 fits=[]
 for p in sorted((run/'stages').glob('fit-*.json')):
  raw=read(p);payload=raw['payload'];fit=payload['fit']
  fits.append({'artifact':str(p.relative_to(S)),'sha256':sha(p),'iteration':int(p.stem.split('-')[1]),'typed_anchors':fit.get('anchors'),'fit_fields':{k:fit.get(k) for k in ['cost','info_rank','info_rank_deficient','warnings','calibration']},'production_summary':next((r for r in measurements.get(rid,{}).get('iterations',[]) if r['artifact']==str(p.relative_to(S))),None)})
 if fits or (run/'sweeps.json.force-tuning.json').exists():
  calibration[rid]={'manifest_applied_parameters':(manifest or {}).get('applied_parameters'),'stop_reason':(manifest or {}).get('stop_reason'),'normal_completion':(manifest or {}).get('normal_completion'),'fit_candidates':fits,'force_checkpoint':read(run/'sweeps.json.force-tuning.json'),'decisions':measurements.get(rid,{}).get('decisions')}
  if not fits:calibration[rid]['failed_collection_partial_points']=[json.loads(line) for p in run.glob('*.partial-points.jsonl') for line in p.open() if line.strip()]
 for pattern in ['sweeps.headless/events.jsonl','stages/history-*.json','sweeps.json.partial-points.jsonl','sweeps.full_auto.log','sweeps.headless/physics.log']:
  for p in run.glob(pattern):inputs['raw_references'].append({'path':str(p.relative_to(S)),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in (S/'evidence').glob('active-friction-audit-*.json'):audits[p.stem]=read(p)
inputs['baseline_manifest']=read(S/'native/friction-baseline/sweeps.headless/manifest.json')
inputs['baseline_terminal_tool_result']=read(S/'evidence/baseline-terminal.json')
baseline=S/'native/friction-baseline'
calibration['supervised-recorder-baseline']={'failure':'recorder acknowledgement/fetch timeout, no geometry','partial_points':[json.loads(line) for p in baseline.glob('*.partial-points.jsonl') for line in p.open() if line.strip()]}
for pattern in ['sweeps.headless/events.jsonl','*.partial-points.jsonl','sweeps.full_auto.log']:
 for p in baseline.glob(pattern):inputs['raw_references'].append({'path':str(p.relative_to(S)),'bytes':p.stat().st_size,'sha256':sha(p)})
inputs['socket_preflight']=read(S/'evidence/preflight-unlayered.json')
inputs['original_design_preserved']=read(S/'evidence/original-design.json')
inputs['noise_only_control_declaration']=read(S/'evidence/noise-only-control-declaration.json')
inputs['final_checks']=read(S/'evidence/final-checks.json')
runtime=read(S/'evidence/final-runtime-status.json',{})
inputs['final_runtime_status']={'isError':runtime.get('isError'),'structuredContent':runtime.get('structuredContent')}
save('evidence/review-inputs.json',inputs);save('evidence/native-audits.json',audits);save('evidence/terminal-snapshots.json',snapshots);save('evidence/failure-windows.json',windows);save('evidence/calibration-evidence.json',calibration)
files={p.name:{'sha256':sha(p),'source':p.read_text()} for p in (S/'harness/policy').glob('*.mjs')}
v1={p.name:{'sha256':sha(p),'source':p.read_text()} for p in (S/'runs/dev1-bounded-preload/collector-policy').glob('*.mjs')}
save('evidence/frozen-policy-sources.json',{'frozen':read(S/'policy-frozen.json'),'files':files,'development_v1_negative_source_not_frozen_for_evaluation':v1})
diffs=[]
for name,rel in [('sweep_data_collection.mjs','autocal/control/behaviors/sweep_data_collection.mjs'),('uncalibrated_actions.mjs','autocal/control/primitives/uncalibrated_actions.mjs')]:
 original=(ROOT/rel).read_text().splitlines(keepends=True);local=(S/'harness/policy'/name).read_text().splitlines(keepends=True)
 diffs.extend(difflib.unified_diff(original,local,fromfile=rel,tofile='session-local/'+name))
(S/'evidence/policy-diff.patch').write_text(''.join(diffs))
selected=['report.md','abstract.md','research.md','evidence/measurements.json','review-manifest.json','policy-frozen.json','evidence/policy-diff.patch','evidence/frozen-policy-sources.json','harness/run.py','harness/prepare.py','harness/analyze.py','harness/torque_slack_probe.mjs','evidence/torque-slack-active.json','evidence/torque-slack-zero.json','evidence/terminal-snapshots.json','evidence/failure-windows.json','evidence/native-audits.json','evidence/generator-reproduction-v2.json','evidence/model-source-map.json','evidence/calibration-evidence.json','runs/nominal-numeric/sweeps.json','runs/nominal-consistent-preload/sweeps.json','budget-ledger.json','evidence/reproduction.md','harness/proposed_motor_perturbation.mjs','proposed-next-discriminator.md','harness/autocal_headless.mjs','harness/terminal-snapshot.txt','design.json','evidence/review-inputs.json']
if (S/'runs/eval0-noise-only-default/sweeps.json').exists():selected.append('runs/eval0-noise-only-default/sweeps.json')
if (S/'final-message.md').exists():selected.append('final-message.md')
assert len(selected)<=32
entries=[{'path':name,'bytes':(S/name).stat().st_size,'sha256':sha(S/name)} for name in selected if name!='review-manifest.json']
save('review-manifest.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'claim':'Nominal calibration good; bounded preload did not recover development collection; active-guide model permits transferred spool load with macroscopic local slack; no hardware or robust-policy claim.','selected_files_excluding_this_manifest':entries,'raw_journals':'Retained session-local; hashes in evidence/review-inputs.json. No rerun required for review.','source_revision':inputs['source_revision'],'native_artifact_sha256':'66a8451bc1a42310e4dfae166288737e595f75bc1173c8f88e92163afb94a5d8'})
save('submission-files.json',{'files':selected})
print(json.dumps({'selected_count':len(selected),'selected_bytes':sum((S/p).stat().st_size for p in selected),'largest_file_bytes':max((S/p).stat().st_size for p in selected)},indent=2))
