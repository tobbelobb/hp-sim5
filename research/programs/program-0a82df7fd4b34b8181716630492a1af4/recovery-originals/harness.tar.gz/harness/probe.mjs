import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createHeadlessWorld} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-8b39a80b/hp-sim-3d/app/headlessWorld.js';
import {SceneEntityInfoComponent,CoefficientOfFrictionComponent,PositionComponent} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-8b39a80b/src/js/cable_joints_3d/ecs.js';
import {CablePathComponent,CableJointComponent} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-8b39a80b/src/js/cable_joints_3d/cable_joints_core.js';
const S='/workspace/hp-sim5/output/research/sessions/attempt-939c073f49004eb6949910600200be51';
let result={steps_per_world:10000,dt:.002,command:'none; unforced settling from authored state',worlds:[]};
for (const id of [process.argv[2] || 'dev1']) {
 const spec=JSON.parse(fs.readFileSync(`${S}/harness/${id}.json`));
 const {world,dt}=createHeadlessWorld(fs.readFileSync(spec.scene,'utf8'),{lineLayeringEnabled:false});
 const engine=world.getResource('cableSolverBackend');world.update(dt);
 const name=e=>world.getComponent(e,SceneEntityInfoComponent)?.name;
 const contacts=world.query([CablePathComponent]).flatMap(p=>{const path=world.getComponent(p,CablePathComponent);return path.jointEntities.slice(0,-1).map((j,i)=>{const joint=world.getComponent(j,CableJointComponent),entity=joint.entityB,idx=engine.index.get(entity);return {path:name(p),link_type:path.linkTypes[i+1],entity:name(entity),mu_ecs:world.getComponent(entity,CoefficientOfFrictionComponent)?.mu??0,mu_native:engine.entityRegion.data[idx*160+105]};});});
 const checkpoints=[];
 for(let step=0;step<10000;step++){world.update(dt);if((step+1)%1000===0)checkpoints.push(Array.from(engine.entityRegion.data));}
 const last=checkpoints.at(-1),hash=createHash('sha256').update(JSON.stringify(checkpoints)).digest('hex');
 result.worlds.push({id,scene_sha256:createHash('sha256').update(fs.readFileSync(spec.scene)).digest('hex'),physics_engine:engine.physicsEngine,artifact:engine.artifactInfo.sha256,contacts,trajectory_sha256:hash,last});
 engine.dispose();
}
const base=result.worlds[0].last;
for(const w of result.worlds){w.max_native_state_delta_from_nominal=Math.max(...w.last.map((v,i)=>Number.isFinite(v)&&Number.isFinite(base[i])?Math.abs(v-base[i]):0));delete w.last;}
fs.writeFileSync(`${S}/evidence/guide-friction-probe-${process.argv[2] || 'dev1'}.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
