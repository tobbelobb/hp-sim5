from pathlib import Path
import re,json,hashlib,datetime
R=Path.cwd();S=Path(__file__).resolve().parents[1];P=S/'harness/policy';P.mkdir(exist_ok=True)
source=R/'autocal/control/behaviors/sweep_data_collection.mjs';s=source.read_text();needle='    return forceMid*2.0;';assert s.count(needle)==1;s=s.replace(needle,'    return resolveCollectionForce({ forceMid, forceMax });')
def absolute_imports(text,original):
 def replace(m):
  uri=m[1]
  return "from '"+(original.parent/uri).resolve().as_uri()+"'" if uri.startswith('.') else m[0]
 return re.sub(r"from '([^']+)'",replace,text)
primitive=R/'autocal/control/primitives/uncalibrated_actions.mjs'
u=primitive.read_text()
old="""  const preloadModes = buildModes(
    Number.isFinite(forceMid)
      ? forceMid * 2.0
      : (Number.isFinite(forceMax) ? forceMax : fallbackForce),
  );"""
new="""  const preloadModes = buildModes(
    Number.isFinite(forceMid) || Number.isFinite(forceMax)
      ? resolveCollectionForce({ forceMid, forceMax })
      : fallbackForce,
  );"""
assert u.count(old)==1;u=u.replace(old,new)
(P/'uncalibrated_actions.mjs').write_text(absolute_imports(u,primitive))
b=absolute_imports(s,source).replace("from '"+primitive.as_uri()+"'", "from './uncalibrated_actions.mjs'")
(P/'sweep_data_collection.mjs').write_text(b)
source_cli=R/'autocal/control/cli/collect_sweep_data.mjs';c=absolute_imports(source_cli.read_text(),source_cli);uri=(R/'autocal/control/behaviors/sweep_data_collection.mjs').as_uri();c=c.replace("from '"+uri+"'","from './sweep_data_collection.mjs'");(P/'collect_sweep_data.mjs').write_text(c)
manifest=dict(policy_id='bounded-preload-v2',stage='development, not frozen for held-out yet',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rule='Consistently at held-drive pullout settling and ordinary data-point preloading, command min(forceMax,5*forceMid) to free sensor instead of 2*forceMid. One bounded rule across both preload paths. Both values come from production noisy-encoder force autotuning. Preserve fallback when both force parameters are missing. No new scene truth, sensor truth, force measurement, fit or stopping input.',trigger='Controller transitions from encoder-observed pullout to held-drive preload settling. Apply the same rule at the later ordinary point-preload transition.',guards='Unchanged stability windows/tolerances/timeouts, fixed-anchor drift guards, force tuner and fit/stopping policy. Command never exceeds autotuned forceMax.',source_sha256={str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in P.glob('*.mjs')},original_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),production_change="return forceMid*2.0 -> return resolveCollectionForce({ forceMid, forceMax })",not_tested='No held-out evaluation yet. Extra point collection cannot repair an upstream no-point settling failure.')
(S/'policy-development.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
