import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createHeadlessWorld} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-b6928f45/hp-sim-3d/app/headlessWorld.js';
import {SceneEntityInfoComponent,CoefficientOfFrictionComponent} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-b6928f45/src/js/cable_joints_3d/ecs.js';
import {StepperMotorComponent} from '/workspace/hp-sim5-worktrees/bounded-research-assignment-b6928f45/hp-sim-3d/app/hangprinter_stepper_motor.js';
import {applyMotorFrictionPlant,readNativeMotorFriction} from './proposed_motor_perturbation.mjs';
const S='/workspace/hp-sim5/output/research/sessions/attempt-11d12ea8033e4ba291598eb250d6e416';
if(process.version!=='v23.11.1')throw Error('Node must be23.11.1');
const result={kind:'bounded torque-mode physical/readback probe',node_version:process.version,steps_per_world:1001,worlds:[],command:'after ordinary first update, A torque mode target +.01Nm for1000 steps/2s; BCD unchanged position mode',manual_prepare:false};
for(const id of ['nominal','development','evaluation']){
 const spec=JSON.parse(fs.readFileSync(`${S}/harness/${id}.json`)),scene=fs.readFileSync(spec.scene,'utf8');
 const {world,dt,bakedScene}=createHeadlessWorld(scene,{lineLayeringEnabled:false,closedLoopMotorsEnabled:false,physicsSubsteps:1});
 const selected=applyMotorFrictionPlant(world,spec.motor_factors);world.update(dt);
 const native=readNativeMotorFriction(world),engine=world.getResource('cableSolverBackend');
 for(const row of selected)for(const [k,v] of Object.entries(row.selected))if(Math.abs(native.find(x=>x.entity===row.entity)[k]-v)>1e-14)throw Error('Readback mismatch');
 const guides=engine.ids.flatMap((e,i)=>{const name=world.getComponent(e,SceneEntityInfoComponent)?.name;return /^Anchor[ABCD]/.test(name)?[{name,ecs_mu:world.getComponent(e,CoefficientOfFrictionComponent)?.mu??0,native_mu:engine.entityRegion.data[i*160+105]}]:[];});
 if(guides.some(g=>g.native_mu!==0))throw Error('Guide friction must be0');
 const entity=world.query([StepperMotorComponent,SceneEntityInfoComponent]).find(e=>world.getComponent(e,SceneEntityInfoComponent).name==='SpoolA');
 const m=world.getComponent(entity,StepperMotorComponent),o=engine.index.get(entity)*160;
 const sample=()=>({encoder_rad:engine.entityRegion.data[o+66],omega_rad_s:Array.from(engine.entityRegion.data.slice(o+72,o+75)),target_torque_nm:engine.entityRegion.data[o+114],torque_mode:engine.entityRegion.data[o+57]});
 const before=sample();m.torqueMode=true;m.targetTorque=.01;
 const samples=[];for(let i=0;i<1000;i++){world.update(dt);if((i+1)%100===0)samples.push(sample());}
 result.worlds.push({id,dt,selected,native,guides,before,after:sample(),samples,scene_sha256:createHash('sha256').update(scene).digest('hex'),baked_scene_sha256:createHash('sha256').update(bakedScene).digest('hex'),native_sha256:engine.artifactInfo.sha256,physics_engine:engine.physicsEngine});engine.dispose();
}
const base=result.worlds[0];for(const w of result.worlds){w.delta_encoder_rad=w.after.encoder_rad-base.after.encoder_rad;w.delta_omega_rad_s=w.after.omega_rad_s.map((x,i)=>x-base.after.omega_rad_s[i]);}
if(result.worlds.slice(1).some(w=>Math.abs(w.delta_encoder_rad)<1e-8))throw Error('Expected changed torque response');
fs.writeFileSync(`${S}/evidence/motor-probe.json`,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result.worlds.map(w=>({id:w.id,native:w.native,after:w.after,delta_encoder_rad:w.delta_encoder_rad})),null,2));
