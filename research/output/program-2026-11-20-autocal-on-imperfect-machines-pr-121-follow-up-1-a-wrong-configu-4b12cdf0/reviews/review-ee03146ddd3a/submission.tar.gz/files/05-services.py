"""Parent-owned services and the narrow HTTP client used by sandboxed MCP."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import secrets
import signal
import socket
import subprocess
import sys
import time

from urllib.error import HTTPError
from urllib.request import Request, urlopen


def free_port():
    return free_ports(1)[0]


def free_ports(count):
    # Keep the sockets bound until all ports are selected so the kernel cannot
    # give two services in the same world the same port.
    with ExitStack() as stack:
        ports = []
        for _ in range(count):
            listener = stack.enter_context(socket.socket())
            listener.bind(('127.0.0.1', 0))
            ports.append(listener.getsockname()[1])
        return ports


def process_identity(pid):
    """Linux birth identity prevents a recycled PID from identifying an old owner."""
    try:
        stat = Path(f'/proc/{pid}/stat').read_text().split(') ')[1].split()
        return {'pid': pid, 'birth': stat[19]}
    except FileNotFoundError:
        return None


def process_live(identity):
    if not identity:
        return False
    current = process_identity(identity['pid'])
    if current != identity:
        return False
    try:
        return Path(f'/proc/{identity["pid"]}/stat').read_text().split(') ')[1].split()[0] != 'Z'
    except FileNotFoundError:
        return False


def register_test_process(process):
    """Record detached test-owned groups so cancellation can also retire services."""
    registry = os.environ.get('HP_SIM5_TEST_PROCESS_REGISTRY')
    if registry:
        try:
            birth = Path(f'/proc/{process.pid}/stat').read_text().split(') ')[1].split()[19]
        except FileNotFoundError:
            return
        # One append per process; descendants inherit the same private registry.
        with Path(registry).open('a') as stream:
            stream.write(json.dumps({'pid': process.pid, 'group': os.getpgid(process.pid), 'birth': birth}) + '\n')


def stop_process(process):
    if process is not None and process.poll() is None:
        # Detached services own their process group, including CLI wrapper children.
        try:
            group = os.getpgid(process.pid) == process.pid
            if group:
                os.killpg(process.pid, signal.SIGTERM)
            else:
                process.terminate()
        except ProcessLookupError:
            process.wait()
            return
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if group:
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
            process.wait()


def request(endpoint, operation, args=None, *, token='', timeout=14430):
    data = json.dumps(args or {}).encode()
    query = Request(endpoint + '/' + operation, data=data,
                    headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'})
    try:
        with urlopen(query, timeout=timeout) as response:
            return json.load(response)
    except HTTPError as error:
        payload = json.load(error)
        raise RuntimeError(payload.get('error', str(error))) from None


def wait_ready(process, endpoint, operation, log, *, token='', timeout=30):
    deadline = time.monotonic() + timeout
    last_error = None
    while time.monotonic() < deadline and process.poll() is None:
        try:
            return request(endpoint, operation, token=token, timeout=1)
        except (OSError, RuntimeError, ValueError) as error:
            last_error = str(error)
            time.sleep(.1)
    raise RuntimeError(f'Service failed readiness ({last_error}); exit={process.poll()}; read {log}')


class RuntimeService:
    def __init__(self, root, directory, viewer_endpoint=None, *, backend='headless-js', record=True, log_directory=None):
        self.root = Path(root)
        self.directory = Path(directory).resolve()
        self.log_directory = Path(log_directory) if log_directory else self.directory
        self.log_directory.mkdir(parents=True, exist_ok=True)
        self.token = secrets.token_hex(32)
        self.endpoint = f'http://127.0.0.1:{free_port()}'
        self.process = None
        self.viewer_endpoint = viewer_endpoint
        self.backend = backend
        self.record = record

    def start(self):
        log_path = self.log_directory / 'runtime.log'
        with log_path.open('w') as log:
            self.process = subprocess.Popen(
                [sys.executable, str(self.root / 'scripts/research_runtime.py'), self.endpoint, str(self.directory)],
                cwd=self.root, env={**os.environ, 'HP_SIM5_RUNTIME_TOKEN': self.token,
                                    'HP_SIM5_PHYSICS_BACKEND': self.backend,
                                    'HP_SIM5_RECORD': '1' if self.record else '0',
                                    'HP_SIM5_RUNTIME_OWNER': json.dumps(process_identity(os.getpid())),
                                    'HP_SIM5_VIEWER_URL': self.viewer_endpoint or '',
                                    'MPLCONFIGDIR': str(self.log_directory / 'matplotlib')},
                stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
        register_test_process(self.process)
        try:
            wait_ready(self.process, self.endpoint, 'status', log_path, token=self.token, timeout=45)
        except Exception:
            self.close()
            raise
        return self

    def call(self, operation, **args):
        return request(self.endpoint, operation, args, token=self.token)

    def close(self):
        if self.process is not None and self.process.poll() is None:
            try:
                request(self.endpoint, 'shutdown', token=self.token, timeout=160)
                self.process.wait(timeout=15)
            except (OSError, RuntimeError, subprocess.TimeoutExpired):
                stop_process(self.process)


def supervised_request(operation, **args):
    endpoint = os.environ.get('HP_SIM5_RUNTIME_URL')
    if not endpoint:
        raise RuntimeError('Start with hp-sim5-research-agent; the launcher supervises native collection services')
    return request(endpoint, operation, args, token=os.environ['HP_SIM5_RUNTIME_TOKEN'])


def supervised_preflight(expected_configuration=None):
    from .preflight import COMMAND_NETWORK_UNKNOWN
    endpoint = os.environ.get('HP_SIM5_RUNTIME_URL')
    if not endpoint:
        error = 'No launcher supervisor is attached'
    else:
        try:
            return request(endpoint, 'preflight', {'expected_configuration': expected_configuration},
                           token=os.environ.get('HP_SIM5_RUNTIME_TOKEN', ''), timeout=20)
        except (OSError, RuntimeError, ValueError) as failure:
            error = str(failure)
    return {'kind': 'tool_check', 'context': 'mcp_service_client', 'outcome': 'blocked',
            'checks': {'supervisor': {'outcome': 'blocked', 'error': error,
                       'next_step': 'Start hp-sim5-research-agent or reattach to its live connection.json; inspect runtime.log'}},
            'command_network': dict(COMMAND_NETWORK_UNKNOWN)}
